| Prénom           | Nom              | Entreprise       | Tuteur entreprise                   | Tuteur école         | Sujet                          | Remarques                      |  
|------------------|------------------|------------------|-------------------------------------|----------------------|--------------------------------|--------------------------------|   
| Carlos           | Aguilar          | MacDonalds       | ronald@mcdonalds.com                | Emmanuel Chaput      | Faire des bigmacs              | Autre demande chez Quick (attente) |
| Alexis           | Girardi          |                  |                                     |                      |                                |                                |
| Axel             | Roudaut          |                  |                                     |                      |                                |                                |
| Axel             | Tripier          |                  |                                     |                      |                                |                                |
| Bérenger         | Foucher          |                  |                                     |                      |                                |                                |
| Dylan            | Iffrig-Bourfa    |                  |                                     |                      |                                |                                |
| Florian          | Barbarin         |                  |                                     |                      |                                |                                |
| Florian          | Postic           |                  |                                     |                      |                                |                                |
| Guillaume        | Squillaci        |                  |                                     |                      |                                |                                |
| Hong Duong       | Tran             |                  |                                     |                      |                                |                                |
| Izhar            | Binarahman       |                  |                                     |                      |                                |                                |
| Julien           | Coupet           |                  |                                     |                      |                                |                                |
| Kévin            | Boyeldieu        |                  |                                     |                      |                                |                                |
| Lena             | David            |                  |                                     |                      |                                |                                |
| Léo              | Georget          |                  |                                     |                      |                                |                                |
| Marc             | Camillière       |                  |                                     |                      |                                |                                |
| Mathilde         | Chauvet          |                  |                                     |                      |                                |                                |
| Maxime           | Gagliardini      |                  |                                     |                      |                                |                                |
| Mohamed          | Beldi            |                  |                                     |                      |                                |                                |
| Nazim            | Mansour          |                  |                                     |                      |                                |                                |
| Nicolas          | Surbayrole       |                  |                                     |                      |                                |                                |
| Paul             | Charayron        |                  |                                     |                      |                                |                                |
| Paul             | Isnardon         |                  |                                     |                      |                                |                                |
| Romain           | Rivière          |                  |                                     |                      |                                |                                |
| Théo             | Cusnir           |                  |                                     |                      |                                |                                |
| Titouan          | Tanguy           |                  |                                     |                      |                                |                                |


# Sujets de stage


## Stages Synacktiv

[Ici](https://www.synacktiv.com/posts/work-with-us/offres-de-stage-2017.html)

## Stages MinDef

[Ici](http://www.stages.defense.gouv.fr/index.php?page=FrancePage)

## Stages Orange Cyber-Défense Toulouse

[Ici](documents/ocd-toulouse/)

## Stages Thalès TCS Toulouse

[Ici](documents/thales-tcs-toulouse/)

## Stage ENAC / ARS
L'objet du stage est de développer un prototype logiciel permettant de faire de l'authentification géographique pour lutter contre la vente en ligne de médicaments contrefaits.

Les compétences attendues sont :
- architecture de sécurité PKI
- développement logiciel web
- virtualisation (le prototype sera construit sous la forme de machines virtuelles) 

Contact Nicolas Larrieu (nicolas.larrieu@enac.fr)

Sujet de stage détaillé [ici](documents/) 

# Stages pris (déplacer ici en remplissant tableau svp)
